This is a bot that plays the trex runner game from Chrome's offline error page. The bot is still not perfect but can score well in most cases. You can play the game as well as see the bot in action on this page - [https://chirag64.github.io/t-rex-runner-bot](https://chirag64.github.io/t-rex-runner-bot).

All rights of the original game's code belong to the Chromium team. Thanks to [Wayou Liu](https://github.com/wayou) for extracting the game from Chrome's files and making it available on Github - [Link to original repository](https://github.com/wayou/t-rex-runner).

Please report bugs / suggestions at [issues](https://github.com/chirag64/t-rex-runner-bot/issues) or at my twitter account - [@Chirag64](https://twitter.com/chirag64).